package threads.lite.utils;

import threads.lite.core.Progress;

public interface ReaderProgress extends Progress {
    long getSize();
}
