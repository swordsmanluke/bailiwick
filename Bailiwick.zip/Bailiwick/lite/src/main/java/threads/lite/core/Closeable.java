package threads.lite.core;


public interface Closeable {
    boolean isClosed();
}
