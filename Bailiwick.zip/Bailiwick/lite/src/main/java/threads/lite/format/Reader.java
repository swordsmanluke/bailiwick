package threads.lite.format;

public interface Reader {
    int read(byte[] bytes);
}
