package threads.lite.core;

public class DataLimitIssue extends Exception {
    public DataLimitIssue(String msg) {
        super(msg);
    }
}
