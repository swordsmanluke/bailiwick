package threads.lite.format;

import androidx.annotation.NonNull;

public interface NodeAdder {
    void add(@NonNull Node nd);
}
