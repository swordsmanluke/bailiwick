package threads.lite.core;

public class ProtocolIssue extends Exception {
    public ProtocolIssue(String msg) {
        super(msg);
    }
}
